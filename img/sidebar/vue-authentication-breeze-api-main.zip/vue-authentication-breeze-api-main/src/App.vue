<script setup>
import Nav from "./components/Nav.vue";
</script>

<template>
  <main>
    <Nav />
    <RouterView />
  </main>
</template>
