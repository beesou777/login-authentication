import { defineStore } from "pinia";
import axios from 'axios'
import router from '@/router/index'

export const useAuthStore = defineStore("auth", {
  state: () => ({
    
    user: JSON.parse(localStorage.getItem('user')),
  }),
  getters:{
    auth_user : (state)=> state.user
  },
  actions: {
    async login(username, password) {
      return new Promise((resolve,reject)=>{
         axios.post("login/", { username, password })
         .then(response =>{
          if(response.data){
            this.user = response.data
            localStorage.setItem('user', JSON.stringify(response.data));
             router.push('/')
          }
          resolve()
         })
         .catch(error => {
          if(error.response){
            if(error.response.data){
              if(error.response.data.msg){
                console.log(error.response.data.msg)
              }
            }
          }
          reject()
         })
      })
     
    },
    async fetch() {
      if(!this.user){
        await router.push('/login');
      }else{
        await axios.get(`user/${this.user.uuid}`)
    
      }
    },
    async logout(){
      localStorage.removeItem('user'),
      window.localStorage.clear()
      localStorage.clear()
      await router.push('/login')
    }
  }
})