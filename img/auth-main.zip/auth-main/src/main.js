import {createApp} from 'vue'
import App from './App.vue'
import './axios'
import router from './router/index'
import { createPinia } from "pinia";
const cors = require('cors')


const app = createApp(App)
const pinia = createPinia();
app.use(pinia)
app.use(router)
app.use(cors)
app.mount('#app')