<template>
  <section class="vh-100 background">
    <div class="container px-5 pb-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-8 col-lg-6 col-xl-5">
          <div class="card shadow-2-strong" style="border-radius: 1rem">
            <div class="card-body p-5">
              <h3 class="text-left">
                <!-- logo ko image -->
                <img src="../../assets/img/ecom_logo.png" style="width:20%;" />

                <!-- header ko part start -->
              </h3>
              <p class="ptext">Email to create password has been sent.</p>
              <h5 class="pb-4">Login</h5>
              <!-- form koo part -->

              <form>
                <div class="form-outline mb-4">
                  <input type="email" id="form2Example17" class="form-control form-control-lg"
                    style="border: 1px solid #d6cfcf" />
                  <label class="form-label" for="form2Example17" style="
                      background: #fff;
                      padding: 0.1rem;
                      margin-top: 0.5rem;
                     
                    ">Email address</label>
                </div>
              </form>
              <!--  login ko button ko part   -->

              <router-link to="login4" class="btn btn-primary btn-lg btn-block" type="submit"
                style="background: var(--primary-color); color: #fff">Login</router-link>
              <!-- hr ko section -->


              <div class="divider d-flex align-items-center my-4">
                <p class="text-center mx-3 mb-0 text-muted py-2" style="font-size: 0.8rem">
                  or login with
                </p>
              </div>
              <!-- footer ko button ko part -->
              <div class="d-flex justify-content-center" style="gap: 1rem">
                <button class="mb-2 login-btn" type="submit">
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Google_%22G%22_Logo.svg/2048px-Google_%22G%22_Logo.svg.png"
                    class="social-login-icon" />
                  Google
                </button>
                <button class="mb-2 login-btn" type="submit">
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Facebook_Logo_%282019%29.png/768px-Facebook_Logo_%282019%29.png"
                    class="social-login-icon" />
                  Facebook
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
</script>

<style>
@import "../../assets/css/style.css";

.divider:after,
.divider:before {
  content: "";
  flex: 1;
  height: 1px;
  background: #999;
}

.ptext {
  width: 100%;
  max-width: 100%;
  height: 50px;
  background: #E7F7E8;
  color: #41C045;
  border: 1px solid #41C045;
  text-align: center;
  padding-top: 12px;
  border-radius: 5px;
}
</style>