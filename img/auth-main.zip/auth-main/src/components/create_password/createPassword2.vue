<template>
  <section class="vh-100" style="background-color: #508bfc">
    <div class="container py-3 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-8 col-lg-6 col-xl-5">
          <div class="card shadow-2-strong" style="border-radius: 1rem">
            <div class="card-body">
              <h3 class="text-left">
              
                <img src="../../assets/img/ecom_logo.png" style="width:20%;"/>

              </h3>
              <!-- heading  -->

              <h5 class="pb-3">Create a password</h5>
              <!-- login ko form -->

              <form>
                <div class="form-outline mb-4">
                  <input
                    type="email"
                    id="form2Example17"
                    class="form-control form-control-lg"
                    style="border: 1px solid #d6cfcf"
                  />
                  <label
                    class="form-label"
                    for="form2Example17"
                    style="
                      background: #fff;
                      padding: 0.1rem;
                      margin-top: 0.5rem;
                    "
                    >Enter your new password</label
                  >
                </div>

                <div class="form-outline mb-4">
                  <input
                    type="password"
                    id="form2Example27"
                    class="form-control form-control-lg"
                    style="border: 1px solid #d6cfcf"
                  />
                  <label
                    class="form-label dark"
                    for="form2Example27"
                    style="
                      background: #fff;
                      padding: 0.1rem;
                      margin-top: 0.5rem;
                    "
                    >Confirm your new password</label
                  >
                </div>
              </form>
              <!-- get started ko form  -->

              <router-link to="/"
              class="btn btn-lg btn-block"
                type="submit"
                style="
                  background: var(--primary-color);
                  color: #fff;
                  padding: 14px 1rem !important;
                ">Reset your password</router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
</script>

<style>
@import "../../assets/css/style.css";
.divider:after,
.divider:before {
  content: "";
  flex: 1;
  height: 1px;
  background: #eee;
}
</style>