import { createRouter, createWebHistory } from 'vue-router'
import GetStarted from '../views/app/loginPage.vue'
import TeSt from '../views/app/welcomePage.vue'


const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      name: 'GetStarted',
      component: GetStarted
    },
    {
      path: '/',
      name: 'test',
      component: TeSt
    },
  ]
})

export default router
