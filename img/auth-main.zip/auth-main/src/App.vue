<template>
    <router-view />
</template>
