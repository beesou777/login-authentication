<template>
  <div>
    hello
  <p v-if="user">hello</p>
    <button @click="logout">logout</button>
  </div>
</template>

<script setup>
import { useAuthStore } from "@/stores/user_store";
import { onMounted } from "vue";

    const userStore = useAuthStore();
    onMounted(async () => {
     const res =  await userStore.user.uuid
        console.log(res)
    });
    async function logout(){
      await userStore.logout()
    }
</script>

