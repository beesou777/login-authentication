<template>
  <div>
    
  </div>
</template>

<script setup>
</script>


<style>
.login-form {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  display: none;
}

</style>